type "make tserver" on the cse03 machine
type "make tclient" on the cse02 machine

or you can type "make" on both machines

then on the cse03, type ./tserver (port number)
then on the cse02, type ./tclient (port number)
the output files are called server.out and client.out
so type nano server.out and client.out to see contents