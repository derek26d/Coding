#include <time.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>

// Given Header
struct tcp_hdr {
    unsigned short int src;
    unsigned short int des;
    unsigned int seq;
    unsigned int ack;
    unsigned short int hdr_flags;
    unsigned short int rec;
    unsigned short int cksum;
    unsigned short int ptr;
    unsigned int opt;
};
// This are the flags for hdr
const int  ACK_BIT = 0,SYN_BIT = 1, FIN_BIT = 0;

int connectToServer(int portNumber, FILE * fp2);

char* convertToBinary(int number);

//This function is used to find checksum
unsigned int cksum(struct tcp_hdr tcp_seg);


void displaySegmentAndWrite(FILE* file_pointer, struct tcp_hdr header_segment, int data_payload);


void transferSegment(int connection_id, FILE * file_pointer, char* message,int sourceport, int desport, int SEQ_nm,
                     int ACK_nm, int ACK_bt, int SYN_bt, int FIN_bt, int payload);


int main(int argc, char** argv) 
{
    
    // The server port that we will connect to
    int tcpServerPort = atoi(argv[1]);

    FILE * clientFile;
    clientFile = fopen("client.out", "ab+");
    // Establishes the connection
    int sockfd = connectToServer(tcpServerPort, clientFile);
    sleep(2);
    // Closes connection
    close(sockfd);
    return 0;
}

int connectToServer(int destport, FILE * fp2) {
    int socket_con;

    // The address information
    struct sockaddr_in serverAddress;
    struct hostent* server;
    socklen_t serverAddress_len;
    socket_con = socket(AF_INET, SOCK_STREAM, 0);
   
        
    bzero(&(serverAddress.sin_zero), 8);


    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(destport);
    serverAddress.sin_addr.s_addr = inet_addr("129.120.151.96");
    
    if(connect(socket_con, (struct sockaddr*) &serverAddress, sizeof(serverAddress)) < 0)
    {
       printf("Error while attempting to connect");
    }
    serverAddress_len = sizeof(serverAddress);
    getsockname(socket_con, (struct sockaddr *) &serverAddress, &serverAddress_len);
    
 
    FILE * file_pointer;
    file_pointer = fopen("./client.out", "w");

    // Send data to Server
    transferSegment(socket_con, fp2, "Transferring TCP segment to the server:\n\n",
                    htons(serverAddress.sin_port), destport, 1212, 0, 0, 1, 0, 0);

    // Get first header from server
    struct tcp_hdr server_header1;
    read(socket_con, ((void*) &server_header1), sizeof(server_header1));
    printf("connection granted from the server:\n\n");
    fprintf(file_pointer, "connection granted from the server:\n\n");
    displaySegmentAndWrite(file_pointer, server_header1, 0);

    // Respond to server
    transferSegment(socket_con, fp2, "Transfer acknowledgement TCP segment to the server:\n\n",
                    ntohs(serverAddress.sin_port), destport, server_header1.ack, server_header1.seq + 1, 1, 0, 0, 0);

    printf("-----------------------------------------------------------\n\n");
    fprintf(file_pointer, "-----------------------------------------------------------\n\n");

    
    // Send a close request
    transferSegment(socket_con, fp2, "Transfer close request TCP segment to the server:\n\n",
                    ntohs(serverAddress.sin_port), destport, 1024, 512, 0, 0, 1, 0);

    // Get the server header
    struct tcp_hdr server_header2;
    read(socket_con, ((void*) &server_header2), sizeof(server_header2));
    printf("Received close request acknowledgement from the server:\n\n");
    fprintf(file_pointer, "Received close request acknowledgement from the server:\n\n");
    displaySegmentAndWrite(file_pointer, server_header2, 0);

    // Get header from server
    struct tcp_hdr server_header3;
    read(socket_con, ((void*) &server_header3), sizeof(server_header3));
    printf("Received second close acknowledgement from the server:\n\n");
    fprintf(file_pointer, "Received second close acknowledgement from the server:\n\n");
    displaySegmentAndWrite(file_pointer, server_header3, 0);

    // Give response to server
    transferSegment(socket_con, fp2, "final close acknowledgement to the server:\n\n",
                    ntohs(serverAddress.sin_port), destport, server_header3.ack + 1, server_header3.seq + 1, 1, 0, 0, 0);

    //Close the connection
    printf("\n");
    fclose(file_pointer);
    return socket_con;
}



char* convertToBinary(int number) {
    char asString[100];
    asString[0] = '\0';
    strcat(asString, "0x");
    for (int index = 5; index >= 0; index--) {
        int k = number >> index;
        if (k & 1) {
            strcat(asString, "1");
        } else {
            strcat(asString, "0");
        }
    }
    return strdup(asString);
}

unsigned int cksum(struct tcp_hdr tcp_seg) {
    unsigned short int cksum_arr[12];
    memcpy(cksum_arr, &tcp_seg, 24);
    unsigned int i, sum = 0, wrap;
    for (i = 0; i < 12; i++) {
        sum = sum + cksum_arr[i];
    }

    wrap = sum >> 16; // Fold once
    sum = sum & 0x0000FFFF;
    sum = wrap + sum;

    wrap = sum >> 16; // Fold once more
    sum = sum & 0x0000FFFF;
    wrap = wrap + sum;
    return wrap;
}

void transferSegment(int connection_id, FILE * file_pointer, char* message, int sourceport, int destport, int SEQ_nm,
                     int ACK_nm, int ACK_bt, int SYN_bt, int FIN_bt, int payload) {

    if(message != NULL) {
        printf("%s", message);
        fprintf(file_pointer,"%s", message);
    }

    struct tcp_hdr header_segment;
    header_segment.src = sourceport;
    header_segment.des = destport;
    header_segment.seq = SEQ_nm;
    header_segment.ack = ACK_nm;
    header_segment.hdr_flags = 0x000000;
    if(ACK_bt == 1) {
        // Sets the ACK bit to 1
        header_segment.hdr_flags |= (1 << ACK_BIT);
    }
    if(SYN_bt == 1) {
        // Sets the SYN bit to 1
        header_segment.hdr_flags |= (1 << SYN_BIT);
    }
    if(FIN_bt == 1) {
        // Sets the FIN bit to 1
        header_segment.hdr_flags |= (1 << FIN_BIT);
    }
    header_segment.rec = 0;
    header_segment.cksum = 0;
    header_segment.ptr = 0;
    header_segment.opt = 0;
    header_segment.cksum = cksum(header_segment);

    displaySegmentAndWrite(file_pointer, header_segment, payload);

    send(connection_id, ((void*) &header_segment), sizeof(header_segment), 0);
}

void displaySegmentAndWrite(FILE* file_pointer, struct tcp_hdr header_segment, int data_payload) {
    printf("Source port number: %d\n", header_segment.src);
    fprintf(file_pointer, "Source port number: %d\n", header_segment.src);
    printf("Destination port number: %d\n", header_segment.des);
    fprintf(file_pointer, "Destination port number: %d\n", header_segment.des);
    printf("Sequence number: %d\n", header_segment.seq);
    fprintf(file_pointer, "Sequence number: %d\n", header_segment.seq);
    printf("Ack number: %d\n", header_segment.ack);
    fprintf(file_pointer, "Ack number: %d\n", header_segment.ack);
    printf("Offset: 6, Header Length: 24\n");
    fprintf(file_pointer, "Offset: 6, Header Length: 24\n");
    printf("Flags: %04u and hdr_flags' binary: %s\n", header_segment.hdr_flags, convertToBinary((int) header_segment.hdr_flags));
    fprintf(file_pointer, "Flags: %04u and hdr_flags' binary: %s\n", header_segment.hdr_flags, convertToBinary((int) header_segment.hdr_flags));
    printf("Rec: 0x%04X\n", header_segment.rec);
    fprintf(file_pointer, "Rec: 0x%04X\n", header_segment.rec);
    printf("Checksum value: 0x%04X\n", (0xFFFF ^ header_segment.cksum));
    fprintf(file_pointer, "Checksum value: 0x%04X\n", (0xFFFF ^ header_segment.cksum));
    printf("Ptr: 0x%04X\n", header_segment.ptr);
    fprintf(file_pointer, "Ptr: 0x%04X\n", header_segment.ptr);
    
    printf("Optional: 0x%08X\n\n\n", header_segment.opt);
    fprintf(file_pointer, "Optional: 0x%08X\n\n\n", header_segment.opt);
   
}






