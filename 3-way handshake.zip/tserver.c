#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <assert.h>
#include <regex.h>
#include <stdbool.h>
#include <sys/stat.h>

// Given Header
struct tcp_hdr {
    unsigned short int src;
    unsigned short int des;
    unsigned int seq;
    unsigned int ack;
    unsigned short int hdr_flags;
    unsigned short int rec;
    unsigned short int cksum;
    unsigned short int ptr;
    unsigned int opt;
};

// These are the bit positions for the three hdr flags
const int ACK_BIT = 0, SYN_BIT = 1, FIN_BIT = 0;

int initiateConnection(int port);

// This function is used to show error messages
void showError(char condition, const char * error_message);

// This function is used for checksum of given header
unsigned int cksum(struct tcp_hdr tcp_seg);

// This function converts number to binary format
char* convertToBinary(int number);

// This function is used for printing content of header_segment and writing them to file
void displaySegmentAndWrite(FILE* file_pointer, struct tcp_hdr header_segment, int payload);

// This function is used to transfer segment, with other information
void transferSegment(int connection_id, FILE* file_pointer, char* message, int sourceport, int destport, int SEQ_nm,
                     int ACK_nm, int ACK_bt, int SYN_bt, int FIN_bt, int payload);
// The driver function
int main(int argc, char** argv) {

    // For server arguments should be 2
    // ./server <port_number>
    if (argc != 2) {
        printf("Invalid Arguments; Usage: ./server <port_number>\n");
        return 1;
    }


    // Opens the server.out file, with write authorities
    FILE * server_fp;
    server_fp = fopen("server.out", "ab+");

    // Get the port number from second argument
    int port_number = atoi(argv[1]);

    // Initiate the connection and wait for client
    int conn_sock = initiateConnection(port_number);

    printf("Connection established\n waiting for client to connect...\n");

    //Accept the connection by cliet
    int client_conn = accept(conn_sock, (struct sockaddr*) NULL, NULL);
    printf("Client connected.\n\n");

    // Make header for client connection
    struct tcp_hdr client_header;
    // Read the header
    read(client_conn, ((void*) &client_header), sizeof(client_header));

    printf("Connected to client.\nReceived TCP segment from client:\n\n");
    fprintf(server_fp, "Connected to Client.\nReceived TCP segment from client:\n\n");
    displaySegmentAndWrite(server_fp, client_header, 0);

   
    // Give Response to client
    transferSegment(client_conn, server_fp, "Transfer segment to the client:\n\n",
                    port_number, client_header.src, 2000, client_header.seq + 1, 1, 1, 0, 0);

    // Make Client connection header for second time
    struct tcp_hdr client_header2;
    //Read the header
    read(client_conn, ((void*) &client_header2), sizeof(client_header2));
    printf("Received acknowledgement from client:\n\n");
    fprintf(server_fp, "Received acknowledgement from client:\n\n");
    // Write To File
    displaySegmentAndWrite(server_fp, client_header2, 0);


    printf("-----------------------------------------------------------\n\n");
    fprintf(server_fp, "-----------------------------------------------------------\n\n");

    // This time close request
    struct tcp_hdr client_header4;
    read(client_conn, ((void*) &client_header4), sizeof(client_header4));
    printf("Received close request from client:\n\n");
    fprintf(server_fp, "Received close request from client:\n\n");
    displaySegmentAndWrite(server_fp, client_header4, 0);

    // sent to client
    transferSegment(client_conn, server_fp, "Transfer close request to the client:\n\n",
                    port_number, client_header4.src, 512, client_header4.seq + 1, 1, 0, 0, 0);

    // send to client
    transferSegment(client_conn, server_fp, "Transfer second close acknowledgement to the client:\n\n",
                    port_number, client_header4.src, 512, client_header4.seq + 1, 0, 0, 1, 0);

    // sent to client
    struct tcp_hdr fromClient4;
    read(client_conn, ((void*) &fromClient4), sizeof(fromClient4));
    printf("Received final close acknowledgement from client:\n\n");
    fprintf(server_fp, "Received final close acknowledgement from client:\n\n");
    displaySegmentAndWrite(server_fp, fromClient4, 0);

    // Close our connection once we are done.
    close(client_conn);

    // close socket
    close(conn_sock);

    // close connection
    fclose(server_fp);
    return 0;
}

int initiateConnection(int port) {

    int socket_con = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in serverAddress;

    showError(socket_con == -1, "Failed to initialize the server socket.");

    bzero(&serverAddress, sizeof(serverAddress));
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_addr.s_addr = INADDR_ANY;
    serverAddress.sin_port = htons(port);

    showError(bind(socket_con, (struct sockaddr *) &serverAddress,
                   sizeof(serverAddress)) == -1, "Failed on binding.");

    int option = 1;

    showError(setsockopt(socket_con, SOL_SOCKET, SO_REUSEADDR,
                         &option, sizeof(option)) == -1, "Failed on socket connection.");

    showError(listen(socket_con, 10) != 0, "Failed to listen to the server.");

    return socket_con;
}

void showError(char condition, const char * error_mgs) {
    if (!condition)
        return;
    perror(error_mgs);
    exit(1);
}


char* convertToBinary(int number) {
    char asString[100];
    asString[0] = '\0';
    strcat(asString, "0x");
    for (int index = 5; index >= 0; index--) {
        int k = number >> index;
        if (k & 1) {
            strcat(asString, "1");
        } else {
            strcat(asString, "0");
        }
    }
    return strdup(asString);
}
unsigned int cksum(struct tcp_hdr tcp_seg) {

    unsigned short int cksum_arr[12];

    memcpy(cksum_arr, &tcp_seg, 24);
    unsigned int i, sum = 0, wrap;
    for (i = 0; i < 12; i++) {
        sum = sum + cksum_arr[i];
    }
// Wrap around once
    wrap = sum >> 16;
    sum = sum & 0x0000FFFF;
    sum = wrap + sum;
// Wrap around once more
    wrap = sum >> 16;
    sum = sum & 0x0000FFFF;
    wrap = wrap + sum;
    return wrap;
}
// This function is used for printing the TCP segments and also for wrinting output to file

void displaySegmentAndWrite(FILE* file_pointer, struct tcp_hdr header_segment, int payload) {

    printf("Source port number: %d\n", header_segment.src);
    fprintf(file_pointer, "Source port: %d\n", header_segment.src);
    printf("Destination port number: %d\n", header_segment.des);
    fprintf(file_pointer, "Destination port: %d\n", header_segment.des);
    printf("Sequence number: %d\n", header_segment.seq);
    fprintf(file_pointer, "Sequence num: %d\n", header_segment.seq);
    printf("Ack number: %d\n", header_segment.ack);
    fprintf(file_pointer, "Ack num: %d\n", header_segment.ack);
    printf("Offset: 6, Header Length: 24\n");
    fprintf(file_pointer, "Offset: 6, Header Length: 24\n");
    printf("Flags: %04u and hdr_flags' binary: %s\n", header_segment.hdr_flags, convertToBinary((int) header_segment.hdr_flags));
    fprintf(file_pointer, "Flags: %04u and hdr_flags' binary: %s\n", header_segment.hdr_flags, convertToBinary((int) header_segment.hdr_flags));
    printf("Rec: 0x%04X\n", header_segment.rec);
    fprintf(file_pointer, "Rec: 0x%04X\n", header_segment.rec);
    printf("Checksum value: 0x%04X\n", (0xFFFF ^ header_segment.cksum));
    fprintf(file_pointer, "Checksum value: 0x%04X\n", (0xFFFF ^ header_segment.cksum));
    printf("Ptr: 0x%04X\n", header_segment.ptr);
    fprintf(file_pointer, "Ptr: 0x%04X\n", header_segment.ptr);

    printf("Optional: 0x%08X\n\n\n", header_segment.opt);
    fprintf(file_pointer, "Optional: 0x%08X\n\n\n", header_segment.opt);

}

// Sends a TCP segment with the following parameters to the client.
void transferSegment(int client_id, FILE* fp, char* message, int sourceport, int destport, 
                     int SEQ_nm, int ACK_nm, int ACK_bt, int SYN_bt, int FIN_bt, int payload) {
    // Prints and writes the specified message.
    if(message != NULL) {
        printf("%s", message);
        fprintf(fp, "%s", message);
    }

    // Creates a new TCP header and fills the fields with the values
    // that were passed to the parameters.
    struct tcp_hdr segment;
    segment.src = sourceport;
    segment.des = destport;
    segment.seq = SEQ_nm;
    segment.ack = ACK_nm;
    segment.hdr_flags = 0x000000;
    if(ACK_bt == 1) {
        // Sets the ACK bit to 1
        segment.hdr_flags |= (1 << ACK_BIT);
    }
    if(SYN_bt == 1) {
        // Sets the SYN bit to 1
        segment.hdr_flags |= (1 << SYN_BIT);
    }
    if(FIN_bt == 1) {
        // Sets the FIN bit to 1
        segment.hdr_flags |= (1 << FIN_BIT);
    }
    segment.rec = 0;
    segment.cksum = 0;
    segment.ptr = 0;
    segment.opt = 0;
    segment.cksum = cksum(segment);

    // Prints and writes the segment out.
    displaySegmentAndWrite(fp, segment, payload);

    // TCP segment is sent to the client through the socket
    write(client_id, ((void*) &segment), sizeof(segment));
}


