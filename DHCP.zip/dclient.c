#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

struct dhcp_pkt 
{
 	unsigned int siaddr; 		// server ip address
 	unsigned int yiaddr; 		// your ip address
 	unsigned int tran_ID; 		// tran id
 	unsigned short int lifetime; 	//lifetime of ip address
};

void displaysegment(struct dhcp_pkt packet); 
 
int main(int argc, char *argv[])
{

	int sockfd;
	struct sockaddr_in servaddr;
	int slen = sizeof(servaddr);
	int getsegment;

	struct dhcp_pkt packet;// create structure
        struct dhcp_pkt packet1;
	
        // erase data
        bzero(&packet , sizeof(packet));
	bzero(&packet1, sizeof(packet1));
				
					
	srand(time(NULL)); // different values
	int n = 0;

  
	sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    	if(sockfd == -1)
    	{
    	   perror("Socket failure\n");
	   exit(1);
    	}
 
    	servaddr.sin_family = AF_INET;
    	servaddr.sin_port = htons(atoi(argv[1]));
    	servaddr.sin_addr.s_addr = inet_addr("129.120.151.96");
        
        // fill structure 
        packet.siaddr = inet_addr("129.120.151.96");
        packet.yiaddr = inet_addr("0.0.0.0");
        packet.tran_ID = rand() %500 + 1;// different numbers
        packet.lifetime = 0; 
      
		
	
	printf("\nSending DHCP segment\n");
	displaysegment(packet);// display packet that is being sent
	// send segment to server

	n = sendto(sockfd, &packet, sizeof(packet), 0, (struct sockaddr *) &servaddr, slen);

	// receive segment from server 
	getsegment = recvfrom(sockfd, &packet1, sizeof(packet1), 0, (struct sockaddr *) &servaddr, &slen);
        		
	printf("\nReceived offer segment\n");
	displaysegment(packet1);

	// fill structure with info from received segment
	packet.yiaddr = packet1.yiaddr;	
	packet.tran_ID = packet1.tran_ID + 1;
	packet.lifetime = packet1.lifetime;	
		
	printf("\nSending request segment\n");
	displaysegment(packet);

        // send to server
	n = sendto(sockfd, &packet, sizeof(packet), 0, (struct sockaddr *) &servaddr, slen);

	// receive from server
	getsegment = recvfrom(sockfd, &packet1, sizeof(packet1), 0, (struct sockaddr *) &servaddr, &slen);
         		
	
	printf("\nReceived ACK segment\n");
	displaysegment(packet1);


	printf("\nEnd DHCP\n");
    	close(sockfd);
    	return 0;
}


void displaysegment(struct dhcp_pkt packet)
{
        // print siaddr and yi addr shifting bits
        printf("siaddr: %d.%d.%d.%d\n", packet.siaddr & 0xFF, (packet.siaddr >> 8) & 0xFF, (packet.siaddr >> 16) & 0xFF, (packet.siaddr >> 24) & 0xFF);
        printf("yiaddr: %d.%d.%d.%d\n", packet.yiaddr & 0xFF, (packet.yiaddr >> 8) & 0xFF, (packet.yiaddr >> 16) & 0xFF, (packet.yiaddr >> 24) & 0xFF);
	
        // print tran_ID and lifetime
        printf("tran_ID : %d\n", packet.tran_ID);
	printf("lifetime: %d seconds\n", packet.lifetime);
}
