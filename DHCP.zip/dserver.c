#include <stdio.h> 
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <math.h>


struct dhcp_pkt
{
 	unsigned int siaddr; 		// server ip address
 	unsigned int yiaddr; 		// your ip address
 	unsigned int tran_ID; 		// transaction ID
 	unsigned short int lifetime; 	// how long ip address last for
};

void displaysegment(struct dhcp_pkt packet); 
int main(int argc, char *argv[])
{

    	struct sockaddr_in servaddr;

    	int sockfd;
	struct sockaddr_in cliaddr;
	socklen_t len = sizeof(cliaddr);
	int getsegment;
    	
	struct dhcp_pkt packet;
	struct dhcp_pkt packet1;	
	int subnet = 0;				
	char netaddr[20];
	int n = 0;

 
        // get network address and subnet
	printf("Network Address: ");	
	scanf("%s", netaddr);
	

	printf("subnet: ");
	scanf("%d", &subnet);
        
        // calculate num of host
        int host = 32 - subnet;
        int calc_numofhost = 1;
        
        for(int i = 1; i <= host ; i++)
        {
            calc_numofhost = calc_numofhost * 2;
        } 
        int numofhost = (calc_numofhost) - 2;
    
        
        // increase yiaddr by 1 by converting
        in_addr_t incraddr = inet_addr(netaddr);
        incraddr = ntohl(incraddr);
        incraddr += 1;
        incraddr = htonl(incraddr);
        
        
	sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    	if (sockfd == -1)
    	{
    	    perror("socket creation failure\n");
	    exit(1);
    	}
         
    	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    	servaddr.sin_port = htons(atoi(argv[1]));
 
	n = bind(sockfd, (struct sockaddr*) &servaddr, sizeof(servaddr));
        
    	while(1)
    	{
		fflush(stdout);

           if(numofhost != 0)
           {
		// Receive from client
		getsegment = recvfrom(sockfd, &packet1, sizeof(packet1), 0, (struct sockaddr *) &cliaddr, &len);
       
         
		printf("\nReceived segment\n");
		displaysegment(packet1); // prints received packet
	        packet.siaddr = packet1.siaddr;		
		packet.yiaddr = incraddr;		
		packet.tran_ID = packet1.tran_ID;		
		packet.lifetime = 3600;			
		printf("\nSending offer segment\n");
		displaysegment(packet);

		// send to the client
		n = sendto(sockfd, &packet, sizeof(packet), 0, (struct sockaddr *) &cliaddr, len);

		// receive the packet
		getsegment = recvfrom(sockfd, &packet1, sizeof(packet1), 0, (struct sockaddr *) &cliaddr, &len);

		
		printf("\nReceived the request segment\n");
		displaysegment(packet1); // print received packet
		packet.tran_ID = packet1.tran_ID;
		printf("\nSending ACK\n");
		displaysegment(packet);

		//send ACK to client
		n = sendto(sockfd, &packet, sizeof(packet), 0, (struct sockaddr *) &cliaddr, len);

		numofhost--;
            }
    	}
 
    	close(sockfd);
    	return 0;
}


void displaysegment(struct dhcp_pkt packet)
{
	//print siaddr and yi addr by shifting bits
        printf("siaddr: %d.%d.%d.%d\n", packet.siaddr & 0xFF, (packet.siaddr >> 8) & 0xFF, (packet.siaddr >> 16) & 0xFF, (packet.siaddr >> 24) & 0xFF);
        printf("yiaddr: %d.%d.%d.%d\n", packet.yiaddr & 0xFF, (packet.yiaddr >> 8) & 0xFF, (packet.yiaddr >> 16) & 0xFF, (packet.yiaddr >> 24) & 0xFF);
	printf("tran_ID : %d\n", packet.tran_ID);
	printf("lifetime: %d seconds\n", packet.lifetime);
}
