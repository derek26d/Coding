type "make dserver" on the cse03 machine
type "make dclient" on the cse02 machine

or you can type "make" on both machines

then on the cse03, type ./dserver (port number)
then type an ip address in format of "0.0.0.0" Ex. 192.168.1.0
then hit enter
then type subnet number
then hit enter

then on the cse02, type ./dclient (port number)
