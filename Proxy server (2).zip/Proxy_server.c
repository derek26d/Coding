#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void  getinput(int);
int   getipaddress(char *, char *);
void  storetime(char *, char *);
void  writeTofile(char *, char *);
void  getTime(char *);


int main(int argc, char *argv[])
{
     struct sockaddr_in servaddr, cliaddr;
     int portnum, sockfd;
     portnum = atoi(argv[1]);// portnumber for server
     sockfd = socket(AF_INET, SOCK_STREAM, 0);
            printf("Socket created.\n");

     bzero(&servaddr, sizeof(servaddr));
     servaddr.sin_family = AF_INET;
     servaddr.sin_addr.s_addr = INADDR_ANY;
     servaddr.sin_port = htons(portnum);//gets portnum argv[1]


     bind(sockfd, (struct sockaddr *) &servaddr, sizeof(servaddr));//bind socket
     listen(sockfd,5);
     int length = sizeof(cliaddr);
        
        //using pid to keep server on
        while (1) 
        {
           int connfd = accept(sockfd, (struct sockaddr *) &cliaddr, &length);
            if (connfd < 0)
                printf("Error on accept.\n");
           int pid = fork();
            if (pid < 0)
                printf("Error on fork.\n");
            if (pid == 0)  
            {
                close(sockfd);
                getinput(connfd);//call function
                exit(0);
            }
            
        } 
        
return 0; 
}

void getinput (int sock)
{
 
    int n, p;
    char str[256], address[16];
    int sockfd;
    struct sockaddr_in server;
    char  receive[2000], msg[2000], *name, ip[16], time[20];

    // Clears buffer and read url from client
    bzero(str,256);
    n = read(sock,str,255);
 
    //Get current time
    getTime(time);
   
    str[n-1] = '\0';
    name = str;

    // get ip from domain
    getipaddress(name, ip); 
    
      
    // socket for web sever
    sockfd = socket(AF_INET , SOCK_STREAM , 0);


    server.sin_addr.s_addr = inet_addr(ip);
    server.sin_family = AF_INET;
    server.sin_port = htons(80);

    // Connect to the web server
    connect(sockfd , (struct sockaddr *)&server , sizeof(server));
   
    
    //store website and timestamp
    storetime(name, time); 

    // GET request and send to the web server
    snprintf(msg, 2000, "GET  / HTTP/1.1\r\nHost: %s\r\n\r\n", name);
    printf("%s", msg);
    send(sockfd , msg , strlen(msg) , 0);

    // verify response
    p = recv(sockfd, receive , 2000 , 0);
  
    // save response
    n = write(sock, receive, 2000);
    writeTofile(receive, time);//call function
}


int getipaddress(char *domain , char *ip)
{
    //convert domain to IP address
    struct addrinfo hints, *servinfo, *p;
    struct sockaddr_in *h;
    int n;
 
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC; 
    hints.ai_socktype = SOCK_STREAM;

      if ((n = getaddrinfo( domain , "http" , &hints , &servinfo)) != 0) //testing
      {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(n));
        return 1;
      }
 
      // Loop through all the results and get ip
      for(p = servinfo; p != NULL; p = p->ai_next) 
      {
        h = (struct sockaddr_in *) p->ai_addr;
        strcpy(ip , inet_ntoa( h->sin_addr ));
      }

  return 0;

} 

void storetime(char *site, char *currentTime)
{
    //store website and timestamp
    char    cache[1000], arr[200];
    int     result = -1, i=0;
  

    // Append data to file
    FILE *list = fopen("list.txt", "a+");
    // create new line
    snprintf(arr, 200, "%s\n", site);

      for(i = 0; fgets(cache, 1000, list) != NULL; i++)
      {
          result = strncmp(arr, cache, result);
            if(result == 0)//check if client visited url before
            {
              printf("Already visited.\n"); 
              return;
            }

          result = -1;
      }
  //put website and timestamp into file
  fprintf(list, "%s  %s\n", arr, currentTime);
  return;
  fclose(list);//close file
} 


void writeTofile(char *receive, char *Time)
{
    //stores web data into a file YYYYMM 
    FILE *web = fopen(Time, "w");//open file

    //store reponse into file
    fprintf(web, "%s", receive);
        return;

    fclose(web);//close file

}



void getTime(char *Time)
{
    //get current time
    time_t  now;
    struct tm *ts;
    char str[80];

    //gets current time
    now = time(NULL);

    //formats the time
    ts = localtime(&now);
    strftime(str, sizeof(str), "%Y%m%d%H%M%S ", ts);//add newline
    strcpy(Time, str);
}
