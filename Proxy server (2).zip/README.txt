Steps to run client and server

1. On csce machine, enter command "gcc Proxy_server.c -o server"
2. Then enter command "./server portnumber" and hit enter. EX. ./server 1122
3. On the other csce machine enter command "gcc http_client.c -o client"
4. Then enter command "./client portnumber" and hit enter. Ex. ./client 1122
5. The port number that both the client and proxy server entered must be the same to communicate
6. After "./client 1122" a prompt will ask for url
7. Enter a url and press enter
8. To enter another url, you have to enter command "./client (same port number" in this case "./client 1122". Hit enter
9. Enter next url and press enter
10. Repeat steps 7-10



ex.
gcc Proxy_server.c -o server
./server 1122

gcc http_client.c -o client
./client 1122
www.google.com
./client 1122
www.yahoo.com