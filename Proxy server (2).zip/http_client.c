#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <netdb.h>



int main(int argc, char *argv[])
{
    int sockfd, n, portnum, p;
    struct sockaddr_in servaddr;
    struct hostent *server;
    char str[256];
    char receive[2000];
    
    portnum = atoi(argv[1]);//get port number from client
  
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(portnum);
    
    //connect to server
    connect(sockfd,(struct sockaddr *)&servaddr,sizeof(servaddr));

    printf("Please enter URL: ");
    bzero(str,256);

    //stores client input into str
    fgets(str,255,stdin);

    //send client input to server
    n = write(sockfd,str,strlen(str));
    
  
    p = read(sockfd, receive, sizeof(receive));//read from server and put into receive
    printf("%s\n",receive); // print the received text from server


    return 0;
}
