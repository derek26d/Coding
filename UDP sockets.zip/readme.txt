type "make udp_server" on the cse03 machine
type "make udp_client" on the cse02 machine

then on the cse03, type ./udp_server (port number)
on the cse02, type ./udp_client (port number) (random.txt)
enter a test message, then press enter
the output file is called newpayload.txt
so type nano newpayload.txt to see if the payload from the client was transferred to the txt file