#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h> 
#include <netinet/udp.h>

#define MAXLINE 2048 



struct segment
{
  unsigned short int source;
  unsigned short int destination;
  unsigned short int length;
  unsigned short int checksum;
  char payload[1024];
};


unsigned short int calc_checksum(unsigned short *fp, int s) 
{ 
   unsigned short int checksum = 0;
   int count = 0;
   
   for(int i = 0; i < s; i++)//calulate checksum 
   { 
     if(checksum + fp[i] > 65536)
     {
       count = 1;
     }
     else
      count = 0;
 
     checksum += fp[i] + count;
   } 
   return ~checksum;
}


int main(int argc, char *argv[]) { 
    int sockfd, segment, n, len, getsource; 
    char buffer[MAXLINE];
    char sourceport[MAXLINE]; 
    struct sockaddr_in servaddr; 
    char datagram[4096], *data;
    char test[MAXLINE];
    char *length;
    FILE* fp;
    char filename[MAXLINE]; 
    // Creating socket file descriptor 
    if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) { 
        perror("socket creation failed"); 
        exit(EXIT_FAILURE); 
    } 
  
    memset(&servaddr, 0, sizeof(servaddr)); 
      
    // Filling server information 
    servaddr.sin_family = AF_INET; 
    servaddr.sin_port = htons(atoi(argv[1])); 
    servaddr.sin_addr.s_addr = inet_addr("129.120.151.96"); 
    
 
    //segment = recvfrom(sockfd, sourceport, MAXLINE, MSG_WAITALL, (struct sockaddr *) &servaddr, &len);
    

    printf("Enter test message: ");
    fgets(test, MAXLINE, stdin);
    sendto(sockfd, test, strlen(test), MSG_CONFIRM, (const struct sockaddr *) &servaddr, sizeof(servaddr));
    
    fp = fopen(argv[2], "r");
 
    //printf("content: %s",argv[2]);
    int c;
    int i = 0;
    int ch = getc(fp);
    char filename2[MAXLINE];
    while(ch != EOF)
    {
       filename[i] = ch;
       ch = getc(fp);
       i++;
    }   
    c = i;
    for(i = 0; i <= c; i++)
    {
      filename2[i] = filename[i];
    }
    //sendto(sockfd, filename2, strlen(filename2), MSG_CONFIRM, (const struct sockaddr *) &servaddr, sizeof(servaddr));    

    n = recvfrom(sockfd, buffer, MAXLINE, MSG_WAITALL, (struct sockaddr *) &servaddr, &len);

    
    int k;
    
    buffer[n] = '\0'; 
    //printf("%s\n", buffer); 
    //printf("%s\n", filename2);
    struct segment udp = {0};
    udp.source = atoi(buffer);//fill udp.source with source number
    udp.destination = atoi(argv[1]);// filld udp.destination with destination number

    sprintf(udp.payload, "%s\n", filename2);
    udp.length = strlen(filename2) + 8;
    int size = sizeof(udp)/2;
    unsigned short int numofele[size];
    memcpy(numofele, &udp, sizeof(udp));//copy memory to numofele
    int value = calc_checksum(numofele, size);
    udp.checksum = value;
    printf("source: %d\n", udp.source);//display source
    printf("destination: %d\n", udp.destination);// display destination 
    printf("Length: %d\n", udp.length);//display length
    printf("checksum: %d\n", udp.checksum);//display checksum
    printf("Payload: %s\n", udp.payload);
    sendto(sockfd, &udp, sizeof(udp), 0, (const struct sockaddr *)&servaddr, sizeof(servaddr));// send to server
    
    close(sockfd); 
    return 0; 
} 
